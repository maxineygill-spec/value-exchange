# Trade rebuild — Condition 2 (simulated trading before sorting)

Rebuilt the trading to match the study spec. Engine logic is now a pure,
unit-tested module; 1,000 simulated playthroughs confirm a participant can
always complete the "≥1 trade with each partner" gate with no soft-locks.

## New flow
mode-select → glossary → deal → **meet-partners (two)** → **trade** → **sort (top N, after trading)** → debrief → summary

## What changed to match the spec
- **Two partners.** The whole deck is split into three equal hands (you + two
  partners) via a proper Fisher–Yates shuffle. No cards are discarded.
- **Trade-until-success gate.** You must complete at least one trade with EACH
  partner before you can finish. "Finish trading" is disabled until then.
- **Probabilistic acceptance.** Partners accept with a base probability (40%,
  i.e. below 50%), which climbs on consecutive rejections so a determined
  participant always lands a trade — rejections are common early but never a
  dead end.
- **Constraints.** A card that has traded with a partner is locked from trading
  with that partner again (no trading back received cards, no ping-pong). Each
  partner stops after a cutoff of offers.
- **Sort moved to AFTER trading**, on the final hand. The pre-trade top-2
  "Prioritize" and "Want" steps were removed (they primed meta-cognition before
  the trade, which the spec puts afterward).

## Tunable parameters — all in `src/lib/tradeEngine.ts`, `DEFAULT_TRADE_CONFIG`
- `baseAcceptProb` (0.40), `rejectionBonus` (0.20), `maxOffersPerPartner` (12),
  `requiredSuccessesPerPartner` (1)

## One decision to confirm (in `useGameState.ts`)
`topN = deckSize === 18 ? 2 : 3`. This matches spec 1d's explicit "top 2 out of
6 / top 3 out of 8". Condition 2's prose says "top 3" flatly — if that's what
you intend, change this line to `const topN = 3;`.

## Not included (easy to add if you want them)
- Counter-offers (spec calls them optional "perhaps"); omitted for robustness.
- Qualtrics/postMessage data bridge (you said later) — export is still a JSON
  download, now reshaped to the new trade-and-sort data model.

## Files
Added: src/lib/tradeEngine.ts, src/screens/Trade.tsx, src/screens/MeetPartners.tsx,
       src/screens/Sort.tsx, src/test/tradeEngine.test.ts
Rewritten: src/hooks/useGameState.ts, src/pages/Index.tsx, src/screens/Summary.tsx
Edited: src/screens/Debrief.tsx
Deleted: src/screens/{Negotiate,Resolution,Prioritize,Want,MeetPartner}.tsx
